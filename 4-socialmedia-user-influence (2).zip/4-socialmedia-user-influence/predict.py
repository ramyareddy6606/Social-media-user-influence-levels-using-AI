import tkinter as tk
from tkinter import messagebox
import pandas as pd
import joblib
from catboost import CatBoostClassifier


model = CatBoostClassifier()
model.load_model("catboost_influence_model.cbm")
FEATURES = joblib.load("influence_model_features.pkl")


root = tk.Tk()
root.title("Social Media Influence Level Prediction")
root.geometry("500x600")

entries = {}


labels = {
    "Age": "Age (years):",
    "Gender": "Gender (Male/Female/Non-binary):",
    "Income (USD)": "Income (USD):",
    "Education Level": "Education Level (High School/Bachelor's/Master's/PhD):",
    "Social Media Usage (Hours/Day)": "Social Media Usage (Hours/Day):",
    "Social Media Platforms": "Social Media Platforms (comma separated):",
    "Purchase Decision": "Purchase Decision (Yes/No):",
    "Amount Spent (USD)": "Amount Spent (USD):"
}

for i, key in enumerate(FEATURES):
    lbl = tk.Label(root, text=labels[key], anchor="w")
    lbl.grid(row=i, column=0, padx=10, pady=5, sticky="w")
    ent = tk.Entry(root, width=40)
    ent.grid(row=i, column=1, padx=10, pady=5)
    entries[key] = ent


def predict_influence():
    data = {}
    for feature in FEATURES:
        value = entries[feature].get()
        if feature in ["Age", "Income (USD)", "Social Media Usage (Hours/Day)", "Amount Spent (USD)"]:
            try:
                value = float(value)
            except:
                messagebox.showerror("Input Error", f"Please enter a valid number for {feature}")
                return
        data[feature] = [value]  

    df_input = pd.DataFrame(data)

    pred = model.predict(df_input)
    result = pred[0]

    messagebox.showinfo("Prediction Result", f"Predicted Influence Level: {result}")

btn = tk.Button(root, text="Predict Influence Level", command=predict_influence, bg="green", fg="white")
btn.grid(row=len(FEATURES), column=0, columnspan=2, pady=20)


root.mainloop()
