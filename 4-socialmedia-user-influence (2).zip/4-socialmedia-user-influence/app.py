from flask import Flask, render_template, request
import pandas as pd
import joblib
from catboost import CatBoostClassifier

app = Flask(__name__)

model = CatBoostClassifier()
model.load_model("catboost_influence_model.cbm")
FEATURES = joblib.load("influence_model_features.pkl")

df = pd.read_csv("dataset.csv")

DROPDOWN_COLUMNS = [
    "Gender",
    "Education Level",
    "Social Media Platforms",
    "Purchase Decision"
]

dropdown_options = {
    col: sorted(df[col].dropna().unique().tolist())
    for col in DROPDOWN_COLUMNS
}

@app.route("/", methods=["GET", "POST"])
def index():
    error = None
    prediction = None
    probabilities = None

    if request.method == "POST":
        data = {}

        for feature in FEATURES:
            value = request.form.get(feature)

            if feature in ["Age", "Income (USD)", "Social Media Usage (Hours/Day)", "Amount Spent (USD)"]:
                try:
                    value = float(value)
                except:
                    error = f"Please enter a valid number for {feature}"
                    return render_template(
                        "index.html",
                        FEATURES=FEATURES,
                        DROPDOWN_COLUMNS=DROPDOWN_COLUMNS,
                        dropdown_options=dropdown_options,
                        error=error
                    )

            data[feature] = [value]

        df_input = pd.DataFrame(data)

        pred = model.predict(df_input)
        prediction = pred[0]

        proba = model.predict_proba(df_input)[0]
        classes = model.classes_
        probabilities = {cls: round(prob * 100, 2) for cls, prob in zip(classes, proba)}

    return render_template(
        "index.html",
        FEATURES=FEATURES,
        DROPDOWN_COLUMNS=DROPDOWN_COLUMNS,
        dropdown_options=dropdown_options,
        error=error,
        prediction=prediction,
        probabilities=probabilities
    )

if __name__ == "__main__":
    app.run(debug=True)
