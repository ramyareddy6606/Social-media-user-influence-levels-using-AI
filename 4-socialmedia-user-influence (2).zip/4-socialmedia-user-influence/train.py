import pandas as pd
from catboost import CatBoostClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import joblib


df = pd.read_csv("dataset.csv")
print(" Dataset Loaded:", df.shape)


TARGET = "Influence Level"

FEATURES = [
    "Age",
    "Gender",
    "Income (USD)",
    "Education Level",
    "Social Media Usage (Hours/Day)",
    "Social Media Platforms",
    "Purchase Decision",
    "Amount Spent (USD)"
]

X = df[FEATURES]
y = df[TARGET]

cat_features = [
    X.columns.get_loc("Gender"),
    X.columns.get_loc("Education Level"),
    X.columns.get_loc("Social Media Platforms"),
    X.columns.get_loc("Purchase Decision")
]


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=42
)


model = CatBoostClassifier(
    iterations=300,
    depth=6,
    learning_rate=0.05,
    loss_function='MultiClass',
    eval_metric='Accuracy',
    random_seed=42,
    verbose=50
)


model.fit(
    X_train, y_train,
    cat_features=cat_features,
    eval_set=(X_test, y_test),
    use_best_model=True
)

print("\nCatBoost training completed")


y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("\nAccuracy:", round(accuracy, 4))

print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

print("\nConfusion Matrix:\n")
print(confusion_matrix(y_test, y_pred))


importance = model.get_feature_importance(prettified=True)
print("\n Feature Importance:\n", importance)


model.save_model("catboost_influence_model.cbm")
joblib.dump(FEATURES, "influence_model_features.pkl")

print("\n Model saved as 'catboost_influence_model.cbm'")
print(" Feature list saved as 'influence_model_features.pkl'")
